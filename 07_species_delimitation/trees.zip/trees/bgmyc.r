spec.probmat <-
function(res) {

	spec.list<-function(res, thresh) {
		tr <- res$tree
		spec <- tr$tip.label
		numtip <- length(tr$tip.label)
		

		max.mrca <- res$mrca[[thresh]] + numtip
		
		numspec <- length(max.mrca)
		
		nest.tip <- function(nod, tr) {
			
			tip <- c()
			child <- tr$edge[tr$edge[,1] == nod, 2]
			
			for (ch in child) {
				if (ch <= numtip) {
					tip <- c(tip, ch)
				} else {
					tip <- c(tip, nest.tip(ch, tr))
				}
			}
			return (tip)
		}
		
		res2 <- c()
		
		for (i in 1:length(max.mrca)) {
			tip.name <- tr$tip.label[nest.tip(max.mrca[i], tr)]
			res2 <- rbind(res2, cbind(i, tip.name))	
		}
		
		
		if (length(spec[-match(res2[,2], spec)]) != 0) {
			numspec <- numspec + 1
			for (s in spec[-match(res2[,2], spec)]) {
				res2 <- rbind(res2, cbind(numspec, s))
				numspec <- numspec + 1
			}
		}
		
		res2 <- data.frame(res2)
		colnames(res2) <- c("GMYC_spec", "sample_name")
		
		return (res2)
	}

assignlists<-c()

if(class(res)=="singlebgmyc"){
	numtip <- length(res$tree$tip.label)
	probmat<-matrix(data=( rep(0, times=(numtip*numtip))), ncol=numtip, nrow=numtip)
	rownames(probmat)<-res$tree$tip.label
	colnames(probmat)<-res$tree$tip.label

	for(j in 1:length(res$par[,3])){
		assignlists<-spec.list(res, res$par[j,3])
		assignlists[,1] <- as.factor(assignlists[,1])
		levs<-levels(assignlists[,1])
		for(i in 1:length(levs)){
		probmat[as.character(assignlists[which(assignlists[,1]==levs[i]),2]),as.character(assignlists[which(assignlists[,1]==levs[i]),2])]<-probmat[as.character(assignlists[which(assignlists[,1]==levs[i]),2]),as.character(assignlists[which(assignlists[,1]==levs[i]),2])]+(1/length(res$par[,3]))
			}
		}
}

if(class(res)=="multibgmyc"){
	numtip <- length(res[[1]]$tree$tip.label)
	probmat<-matrix(data=( rep(0, times=(numtip*numtip))), ncol=numtip, nrow=numtip)
	rownames(probmat)<-res[[1]]$tree$tip.label
	colnames(probmat)<-res[[1]]$tree$tip.label
	ntrees<-length(res)
	totalsamp<-ntrees*length(res[[1]]$par[,1])

	for(q in 1:ntrees){
		for(j in 1:length(res[[q]]$par[,3])){
			assignlists<-spec.list(res[[q]], res[[q]]$par[j,3])
			assignlists[,1] <- as.factor(assignlists[,1])
			levs<-levels(assignlists[,1])
			for(i in 1:length(levs)){
				probmat[as.character(assignlists[which(assignlists[,1]==levs[i]),2]),as.character(assignlists[which(assignlists[,1]==levs[i]),2])]<-probmat[as.character(assignlists[which(assignlists[,1]==levs[i]),2]),as.character(assignlists[which(assignlists[,1]==levs[i]),2])]+1

				}
			}
	}
	probmat<-probmat/totalsamp
}

class(probmat)<-"bgmycprobmat"
return(probmat)

}








plot.singlebgmyc <-
function(result, burnin=0, thinning=1){
	par(mfrow=c(2,2))
	ylabels<-c("p.div","p.coal","threshold","logposterior")
	for(i in 1:4){
		plot(result$par[,i][ ((burnin+1)/thinning): (length(result$par[,1])/thinning)*thinning], xlab="generations", ylab=ylabels[i])
	}
}


plot.multibgmyc <-
function(result, plot=TRUE){

	parmat<-c()
	for(i in 1:length(result)){
		parmat<-rbind(parmat, result[[i]]$par)
		}
		
	if(plot){
		par(mfrow=c(2,2))
		ylabels<-c("p.div","p.coal","threshold","logposterior")
		for(i in 1:4){
			plot(parmat[,i], xlab="generations", ylab=ylabels[i])
			}
		}
	
	else{return(parmat)}
}


plot.bgmycrates<-function(checkratesoutput){
  par(mfrow=c(2,2))
  plot(log(checkratesoutput[,5]/checkratesoutput[,6], base=10), ylim=c(-1,3), xlab="mcmc samples", ylab="log(coalescence rate/Yule rate)")
  plot((checkratesoutput[,5]/checkratesoutput[,6]), ylim=c(-10,100), xlab="mcmc samples", ylab="coalescence rate/Yule rate)")
  
  hist(log(checkratesoutput[,5]/checkratesoutput[,6], base=10), breaks=20, xlab="log(coalescence rate/Yule rate)", main=NULL)
  hist((checkratesoutput[,5]/checkratesoutput[,6]), breaks=20, xlab="coalescence rate/Yule rate", main=NULL)
  
  }
  
  
plot.bgmycprobmat <-
function(probmat, tree){
	
	ntip<-length(tree$tip.label)
	
	tree<-reorder.phylo(tree, order="cladewise")
	
	edge<-tree$edge[which(tree$edge[,2]<(ntip+1)),]
	tiplab<-tree$tip.label[edge[,2]]

	orderedmat<-probmat[tiplab,]
	orderedmat<-orderedmat[,tiplab]
	
	par(fig=c(0, 0.48, 0, 1))
	plot(tree, show.tip.label=FALSE, no.margin=TRUE)

	par(fig=c(0.47, 0.96, 0.035, 0.965), new=TRUE)
	image(x=c(1:ntip+1), y=c(1:ntip), z=orderedmat, axes=FALSE, breaks=c(0, 0.05, 0.49999999, 0.899999999, 0.9499999999, 1), col=heat.colors(5))
	
	par(fig=c(0.968, 0.99, 0.035, 0.965), new=TRUE)
	leg<-matrix(nrow=1, ncol=20, data=seq(from=0.025, to=1, by=0.05))
	image(y=seq(from=0, to=1, by=0.05), x=1, z=leg, col=heat.colors(5), breaks=c(0, 0.05, 0.5, 0.9, 0.95, 1), axes=FALSE)

	abline(h=c(0.95, 0.9, 0.5, 0.05))
	text(x=1, y=0.975, labels="p=\n0.95-1", cex=0.5, srt=90)
	text(x=1, y=0.925, labels="p=0.9-\n0.95", cex=0.5, srt=90)
	text(x=1, y=0.7, labels="p=0.5-0.9", cex=0.5, srt=90)
	text(x=1, y=0.275, labels="p=0.05-0.5", cex=0.5, srt=90)
	text(x=1, y=0.025, labels="p=0-\n0.05", cex=0.5, srt=90)
	}



gmyc.5parameter.lik <-
function(params, data) {
		p <- c(rep(params[2], data$n[[params[5]]]), params[1])					
		lambda <- c(rep(params[4], data$n[[params[5]]]), params[3]) 
		b <- t(data$list.i.mat[[params[5]]]^p) %*% lambda			
		lik <- b * exp(-b * data$internod)					
		return(sum(log(lik)))
	}


checkrates<-function(result){
  
  bgmyc.lambda<-function(params, data) {
    n<-data$n[[params[3]]]
    p <- c(rep(params[2], n), params[1])					
    lambda <- sum(data$list.s.nod[[params[3]]][1:n, ])/sum(data$list.i.mat[[params[3]]][1:n, ]^p[-(n + 1)] %*% data$internod)
    lambda <- c(lambda, sum(data$list.s.nod[[params[3]]][n + 1, ])/data$list.i.mat[[params[3]]][n + 1, ]^p[n + 1] %*% data$internod) 
    return(lambda[c(2,1)])
  }
  
  
  branchrates<-c()
  if(class(result)=="multibgmyc"){
    for(i in 1:length(result)){
      print(i)
      bgmyc.dataprep(result[[i]]$tree)->dat
      for(j in 1:length(result[[i]]$par[,1])){
        branchrates<-rbind(branchrates, c(result[[i]]$par[j,1:3], bgmyc.lambda(result[[i]]$par[j,1:3], dat)))
        } 
      }
    }
    if(class(result)=="singlebgmyc"){
      bgmyc.dataprep(result$tree)->dat
      for(j in 1:length(result$par[,1])){
        branchrates<-rbind(branchrates, c(result$par[j,1:3], bgmyc.lambda(result$par[j,1:3], dat)))
      }
    }
    
  ratemod<-((branchrates[,3]^branchrates[,1]))/branchrates[,3]
  branchrates<-cbind(branchrates, branchrates[,4]*ratemod) 
  
  colnames(branchrates)<-c("p.div", "p.coal", "threshold", "lambda.div", "lambda.coal", "lambda.div.mod")
  class(branchrates)<-"bgmycrates"
  return(branchrates)
  }
  
  
bgmyc.spec <-
function(res, filename=NULL, cmatrix=NULL) {
	temp.file.mcmc<-tempfile()
	
	if(class(res)=="singlebgmyc"){
		numsamp<-length(res$par[,1])
		tr <- res$tree
		spec <- tr$tip.label
		numtip <- length(tr$tip.label)
		output<-list()
		
		nest.tip <- function(nod, tr) {
			
			tip <- c()
			child <- tr$edge[tr$edge[,1] == nod, 2]
			
			for (ch in child) {
				if (ch <= numtip) {
					tip <- c(tip, ch)
				} else {
					tip <- c(tip, nest.tip(ch, tr))
				}
			}
			return (tip)
		}
		
		clusters<-list()

		for (i in 1:length(res$par[,3])){


			max.mrca <- res$mrca[[res$par[(i),3]]] + numtip
			numspec <- length(max.mrca)

			result <- c()
			delimit<-list()
			
			for(j in 1:numspec){
				tip.name <- tr$tip.label[nest.tip(max.mrca[j], tr)]
				result <- rbind(result, cbind(j, tip.name))
				cat(paste(unlist(sort(tip.name)), collapse="	"), "\n", file=temp.file.mcmc, append=TRUE)
				delimit[[j]]<-sort(tip.name)
			}

			if (length(spec[-match(result[,2], spec)]) != 0) {
				numspec <- numspec + 1	
				for (s in spec[-match(result[,2], spec)]) {
					result <- rbind(result, cbind(numspec, s))
					cat(s, "\n", file=temp.file.mcmc, append=TRUE)
					delimit[[numspec]]<-s
					numspec <- numspec + 1
					
				}
			}
			clusters[[i]]<-delimit
		}

		commandline<-c("sort ", temp.file.mcmc, " | uniq -c | sed s/'^ *'// | sed s/' $'//")
			
		read.table(pipe(paste(unlist(commandline), collapse = " ")), sep=" ")->output[["specprobs"]]
		closeAllConnections()

		output$specprobs<-output$specprobs[order(output$specprobs[,1], decreasing=TRUE),]
		output$specprobs[,1]<-output$specprobs[,1]/numsamp
		
		if(!is.null(filename)){
			write.table(output[["specprobs"]], filename, row.names=FALSE, col.names=FALSE)
			}
		
		
		matrices<-list()
		if(!is.null(cmatrix)){

			for(k in 1:length(clusters)){
				vec<-c()
				for(m in 1:length(clusters[[k]])){
					vec<-c(vec, clusters[[k]][[m]][1])
				}
				cols<-c(colnames(cmatrixname))

				newmat<-matrix(nrow=length(clusters[[k]]), ncol=ncol(cmatrixname), dimnames=(list(vec, cols) ))
				

				for(n in 1:length(clusters[[k]])){
					if(length(clusters[[k]][[n]])>1){			
						newmat[clusters[[k]][[n]][[1]],]<-colSums(cmatrixname[clusters[[k]][[n]],])	
					}else{newmat[clusters[[k]][[n]][[1]],]<-cmatrixname[clusters[[k]][[n]],]}
				}
				matrices[[k]]<-newmat
			}
			
		output[["matrices"]]<-matrices	
			
		}

	}

	if(class(res)=="multibgmyc"){
	
		ntrees<-length(res)	
		samp<-length(res[[1]]$par[,1])
		totalsamp<-length(res[[1]]$par[,1])*length(res)
		numtip <- length(res[[1]]$tr$tip.label)

		nest.tip <- function(nod, tr) {
			
			tip <- c()
			child <- tr$edge[tr$edge[,1] == nod, 2]
		
			for (ch in child) {
				if (ch <= numtip) {
					tip <- c(tip, ch)
				} else {
					tip <- c(tip, nest.tip(ch, tr))
				}
			}
			return (tip)
		}


		clusters<-list()
		for(h in 1:ntrees){
			tr <- res[[h]]$tree
			spec <- tr$tip.label
			output<-list()
		

			for (i in 1:samp){

				max.mrca <- res[[h]]$mrca[[res[[h]]$par[(i),3]]] + numtip
				numspec <- length(max.mrca)

				result <- c()
				delimit<-list()
			
				for(j in 1:numspec){
					tip.name <- tr$tip.label[nest.tip(max.mrca[j], tr)]
					result <- rbind(result, cbind(j, tip.name))
					cat(paste(unlist(sort(tip.name)), collapse="	"), "\n", file=temp.file.mcmc, append=TRUE)
					delimit[[j]]<-sort(tip.name)
				}

				if (length(spec[-match(result[,2], spec)]) != 0) {
					numspec <- numspec + 1	
					for (s in spec[-match(result[,2], spec)]) {
						result <- rbind(result, cbind(numspec, s))
						cat(s, "\n", file=temp.file.mcmc, append=TRUE)
						delimit[[numspec]]<-s
						numspec <- numspec + 1
					
					}
				}
				clusters[[i+(samp*(h-1))]]<-delimit
			}
		}

		matrices<-list()

		if(!is.null(cmatrix)){


			for(k in 1:length(clusters)){
				vec<-c()
				for(m in 1:length(clusters[[k]])){
					vec<-c(vec, clusters[[k]][[m]][1])
				}
				cols<-c(colnames(cmatrixname))

				newmat<-matrix(nrow=length(clusters[[k]]), ncol=ncol(cmatrixname), dimnames=(list(vec, cols) ))
				

				for(n in 1:length(clusters[[k]])){
					if(length(clusters[[k]][[n]])>1){			
						newmat[clusters[[k]][[n]][[1]],]<-colSums(cmatrixname[clusters[[k]][[n]],])	
					}else{newmat[clusters[[k]][[n]][[1]],]<-cmatrixname[clusters[[k]][[n]],]}
				}
				matrices[[k]]<-newmat
			}
			
		output[["matrices"]]<-matrices	
			
		}

		commandline<-c("sort ", temp.file.mcmc, " | uniq -c | sed s/'^ *'// | sed s/' $'//")
			
		read.table(pipe(paste(unlist(commandline), collapse = " ")), sep=" ")->output[["specprobs"]]
		closeAllConnections()

		output$specprobs<-output$specprobs[order(output$specprobs[,1], decreasing=TRUE),]
		output$specprobs[,1]<-output$specprobs[,1]/totalsamp
		
		if(!is.null(filename)){
			write.table(output[["specprobs"]], filename, row.names=FALSE, col.names=FALSE)
			}
			
	}
		unlink(temp.file.mcmc)
		return(output)
}



bgmyc.singlephy <-
function(phylo, mcmc, burnin, thinning, py1=0, py2=2, pc1=0, pc2=2, t1=2, t2=51, scale=c(20, 10, 5.00), start=c(1.0, 0.5, 50.0), sampler=bgmyc.gibbs, likelihood=bgmyc.lik, prior=bgmyc.prior){
	
  cat("You are running bGMYC on a single phylogenetic tree.\n")
  cat("This tree contains ", length(phylo$tip.label), " tips.\n")
  cat("The Yule process rate change parameter has a uniform prior ranging from ", py1, " to ", py2, ".\n")
  cat("The coalescent process rate change parameter has a uniform prior ranging from ", pc1, " to ", pc2, ".\n")
  cat("The threshold parameter, which is equal to the number of species, has a uniform prior ranging from ", t1, " to ", t2, ". The upper bound of this prior should not be more than the number of tips in your trees.\n")
  cat("The MCMC will start with the Yule parameter set to ", start[1], ".\n")
  cat("The MCMC will start with the coalescent parameter set to ", start[2], ".\n")
  cat("The MCMC will start with the threshold parameter set to ", start[3], ". If this number is greater than the number of tips in your tree, an error will result.\n")
  
  cat("Given your settings for mcmc, burnin and thinning, your analysis will result in ", (mcmc-burnin)/thinning, " samples being retained.\n")
  
	bgmyc.dataprep(phylo)->data
	sampler(data, m=mcmc, burnin, thinning, py1, py2, pc1, pc2, t1, t2, scale=scale, start=start, likelihood=likelihood, prior=prior)->output
	return(output)
	
	}




bgmyc.prior <-
function(params, py1, py2, pc1, pc2, t1, t2){
	loglik<-dunif(params[1], min=py1, max=py2, log=TRUE)+
			dunif(params[2], min=pc1, max=pc2, log=TRUE)+
			dunif(params[3], min=t1, max=t2, log=TRUE)
	return(loglik)
	}


bgmyc.point<-function(probmat, ppcutoff){
  seqs<-rownames(probmat)
  pointest<-list(seqs[1])
  nspec<-1
  for(i in 2:length(seqs)){
    flip<-0
    for(j in 1:length(pointest)){
      if(any(probmat[i,pointest[[j]]]>ppcutoff)){
        pointest[[j]]<-c(pointest[[j]], seqs[i])
        flip<-flip+1
      }
    }
    if(flip==0){
      nspec<-nspec+1
      pointest[[nspec]]<-seqs[i]
    }
    if(flip>1){
      print("warning: not all members of each cluster have conspecificity probability greater than specified with every other member in the cluster.")
    }
  }
  
  pointfin<-list()
  nspec<-1
  for(i in 1:(((length(seqs)^2)-length(seqs)))/2)
    
    
    while(any(duplicated(unlist(pointest)))){
      print("merging as per previous warning")
      dupl<-duplicated(unlist(pointest))
      dupes<-unlist(pointest)[dupl]
      lvec<-c()
      for(i in 1:length(pointest)){lvec<-c(lvec, dupes[1]%in%pointest[[i]])}	
      newspec<-unlist(pointest[lvec])
      newspec<-newspec[!duplicated(newspec)]
      pointest<-pointest[!lvec]
      pointest[[length(pointest)+1]]<-newspec
    }
  return(pointest)
}


bgmyc.multiphylo <-
function(multiphylo, mcmc, burnin, thinning, py1=0, py2=2, pc1=0, pc2=2, t1=2, t2=51, scale=c(20, 10, 5.00), start=c(1.0, 0.5, 50.0), sampler=bgmyc.gibbs, likelihood=bgmyc.lik, prior=bgmyc.prior){
	
  ntre<-length(multiphylo)
  
  cat("You are running a multi tree analysis on ", ntre, " trees.\n")
  cat("These trees each contain ", length(multiphylo$tip.label[[1]]), " tips.\n")
  cat("The Yule process rate change parameter has a uniform prior ranging from ", py1, " to ", py2, ".\n")
  cat("The coalescent process rate change parameter has a uniform prior ranging from ", pc1, " to ", pc2, ".\n")
  cat("The threshold parameter, which is equal to the number of species, has a uniform prior ranging from ", t1, " to ", t2, ". The upper bound of this prior should not be more than the number of tips in your trees.\n")
  cat("The MCMC will start with the Yule parameter set to ", start[1], ".\n")
  cat("The MCMC will start with the coalescent parameter set to ", start[2], ".\n")
  cat("The MCMC will start with the threshold parameter set to ", start[3], ". If this number is greater than the number of tips in your tree, an error will result.\n")
  cat("Given your settings for mcmc, burnin and thinning, your analysis will result in ", ((mcmc-burnin)/thinning)*ntre, " samples being retained.\n")
  
  
  
	outputlist<-list()
		
	for(i in 1:ntre){
		bgmyc.dataprep(multiphylo[[i]])->data
		NNodes<-data$tree$Nnode
		sampler(data, m=mcmc, burnin, thinning, py1=py1, py2, pc1, pc2, t1, t2, scale=scale, start=start, likelihood=likelihood, prior=prior)->outputlist[[i]]
		cat("tree number ", i, "is finished", "\n")
		}
	class(outputlist)<-"multibgmyc"
	return(outputlist)
	}



bgmyc.lik <-
function(params, data) {
			n<-data$n[[params[3]]]
			p <- c(rep(params[2], n), params[1])					
			lambda <- sum(data$list.s.nod[[params[3]]][1:n, ])/sum(data$list.i.mat[[params[3]]][1:n, ]^p[-(n + 1)] %*% data$internod)

			lambda <- c(rep(lambda, n), sum(data$list.s.nod[[params[3]]][n + 1, ])/data$list.i.mat[[params[3]]][n + 1, ]^p[n + 1] %*% data$internod) 
			b <- t(data$list.i.mat[[params[3]]]^p) %*% lambda			
			lik <- b * exp(-b * data$internod)					
			out<-sum(log(lik))
		if(is.nan(out)){
			return(-Inf)
			}
		else{
			return(sum(log(lik)))}
	}





bgmyc.gibbs <-
function (data, m, burnin=1, thinning=1, py1, py2, pc1, pc2, t1, t2, scale=c(20, 10, 5.00), start=c(1.0, 0.5, 50.0), likelihood, prior) {

	
	NNodes<-data$tree$Nnode
	p = length(start)
	vth = array(0, dim = c(m, p+1))
	f0 = likelihood(start, data)+prior(start, py1, py2, pc1, pc2, t1, t2) #####################* PRIOR
	arate = array(0, dim = c(1, p))
	th0 = start
	th1 = th0
	mover<-function(index, initial){
		if(index == 1){return(rgamma(1, shape=scale[1], rate=(scale[1]/initial[1])))}
		if(index == 2){return(rgamma(1, shape=scale[2], rate=(scale[2]/initial[2])))}
		if(index == 3){return(round(initial[3] + rnorm(1) * scale[3]))}
	}

	for (i in 1:m) {
		th1<-th0

		for (j in 1:p) {

			th1[j] = mover(j,th0)
			
			if(j<3){
				f1 = likelihood(th1, data)+prior(th1, py1, py2, pc1, pc2, t1, t2) ##############* PRIOR
				u = runif(1) < exp(f1 - f0)*(dgamma(th0[j], shape=scale[j], rate=(scale[j]/th1[j])) / dgamma(th1[j], shape=scale[j], rate=(scale[j]/th0[j])))
			}else{
				if(th1[3]<NNodes && th1[3]>=2){  
					f1 = likelihood(th1, data)+prior(th1, py1, py2, pc1, pc2, t1, t2) ###############*PRIOR
				}else{
					f1=log(0)
				}
				u = runif(1) < exp(f1 - f0)
			}
			
			

			if (u){
				th0[j] = th1[j] 
				f0 = f1 
			}
			else {
				th0[j] = th0[j]
				f0 =f0			
			}
							
			vth[i, j] = th0[j]
			vth[i,p+1] = f0
			arate[j] = arate[j] + u
		}		
	
		#if((i==m*0.1)|(i==m*0.2)|(i==m*0.3)|(i==m*0.4)|(i==m*0.5)|(i==m*0.6)|(i==m*0.7)|(i==m*0.8)|(i==m*0.9)|(i==m)){
		#cat((i/m)*100, "%","\n")
		#}
	}
	arate = arate/m
	stuff = list(par = vth[((burnin+1)/thinning):(m/thinning)*thinning,], accept = arate, tree = data$tree, mrca = data$mrca.nodes)
	
	parnames<-c("py", "pc", "th")
	cat("acceptance rates", "\n", parnames, "\n", stuff$accept, "\n")
	
	class(stuff)<-"singlebgmyc"
	return(stuff)
}





bgmyc.dataprep <-
function(tr){ 	

	if (!is.ultrametric(tr)) {
		stop("Your input tree is not ultrametric. This method requires that trees be ultrametric.")
	}
	if (!is.binary(tr)) {
		stop("Your input tree is not fully bifurcating, please resolve with zero branch lengths")
	}
	if (0 %in% tr$edge.length[which(tr$edge[,2]<=length(tr$tip.label))]) {
		stop("Your tree contains tip branches with zero length. This will wreak havoc with the GMYC model.")
	}


	local.env <- environment()
	read.data <- function(z = 1) {
		bt <- -branching.times(tr)
		bt[bt > -1e-06] <- -1e-06
		names(bt) <- NULL
		assign("bt", bt, envir = local.env)
		assign("sb", sort(bt), envir = local.env)
		assign("numnod", length(bt), envir = local.env)
		assign("numtip", length(tr$tip.label), envir = local.env)
		assign("numall", length(bt) + length(tr$tip.label), envir = local.env)
		assign("nthresh", numnod, envir = local.env)
		
		internod <- sb[2:numnod] - sb[1:numnod - 1]
		internod[numnod] <- 0 - sb[numnod]
		assign("internod", internod, envir = local.env)

		assign("nesting", sapply((numtip + 1):numall, nesting.nodes), 
			envir = local.env)
		assign("nested", sapply((numtip + 1):numall, nest.nodes), 
			envir = local.env)

		ancs <- cbind(tr$edge[pmatch((1:numnod + numtip), tr$edge[, 
			2]), 1], (1:numnod + numtip))
		bt.ancs <- cbind(bt[ancs[, 1] - numtip], bt[ancs[, 2] - 
			numtip])
		assign("bt.ancs", bt.ancs, envir = local.env)
		
	}

					  nest.nodes <- function(x, p = 0) {
						  numtip <- length(tr$tip.label)
						  nods <- array(NA, 0)
						  desc <- as.integer(tr$edge[, 2][tr$edge[, 1] == x])
						  if (desc[1] > numtip) {
							  nods <- c(nods, desc[1], nest.nodes(desc[1]))
						  }
						  if (desc[2] > numtip) {
							  nods <- c(nods, desc[2], nest.nodes(desc[2]))
						  }
						  if (length(nods) > 0) {
							  return(nods)
						  }
						  else {
							  return(NULL)
						  }
					  }

					  nesting.nodes <- function(x, p = 0) {
						  numtip <- length(tr$tip.label)
						  nod <- array(NA, 0)
						  if (x >= numtip + 2) {
							  anc <- as.integer(tr$edge[, 1][tr$edge[, 2] == x])
						  }
						  else {
							  anc <- 1
						  }
						  if (anc >= numtip + 2) {
							  nod <- c(nod, anc, nesting.nodes(anc))
						  }
						  if (anc == numtip + 1) {
							  nod <- c(nod, anc)
						  }
						  if (length(nod) > 0) {
							  return(nod)
						  }
						  else {
							  return(NULL)
						  }
					  }


	create.mat<-function(nthresh=numnod){
	
		mrca.nodes<-list()
		nod.types<-list()
		n<-list()
		list.i.mat<-list()
		list.s.nod<-list()
		nod<-list()
		
		for (j in (2:nthresh)) {										
			threshy <- sb[j]									
			tmp <- (bt.ancs[, 1] < threshy) & (bt.ancs[, 2] >= threshy)		
			nod.type <- tmp + (bt >= threshy)								
			mrca.nodes[[j]] <- which(nod.type == 2)				
			if (nod.type[1] == 1) 							
				nod.type[1] <- 2
			nod.types[[j]]<-nod.type		
			
	   		n[[j]]<-length(mrca.nodes[[j]])		
	   		
			list.i.mat[[j]] <- matrix(0, ncol = numnod, nrow = (n[[j]] + 1))			
			list.s.nod[[j]] <- matrix(0, ncol = numnod, nrow = (n[[j]] + 1))			

			nod[[j]]<-nod.types[[j]][order(bt)]	

			for (i in (1:n[[j]])) {										
				list.s.nod[[j]][i, mrca.nodes[[j]][i]] <- 2										
 				if (!is.null(nested[[mrca.nodes[[j]][i]]])) {				
					list.s.nod[[j]][i, nested[[mrca.nodes[[j]][i]]] - numtip] <- 1		
				}
				list.s.nod[[j]][i, ] <- list.s.nod[[j]][i, order(bt)]		
				list.i.mat[[j]][i, ][list.s.nod[[j]][i, ] == 2] <- 2		
				list.i.mat[[j]][i, ][list.s.nod[[j]][i, ] == 1] <- 1		
				list.i.mat[[j]][i, ] <- cumsum(list.i.mat[[j]][i, ])		
			}
			list.s.nod[[j]][list.s.nod[[j]] == 2] <- 1								

			list.i.mat[[j]] <- list.i.mat[[j]] * (list.i.mat[[j]] - 1)					
			list.s.nod[[j]][n[[j]] + 1, ] <- nod[[j]] == 0
			list.i.mat[[j]][n[[j]] + 1, nod[[j]] == 0] <- 1
			list.i.mat[[j]][n[[j]] + 1, nod[[j]] == 2] <- -1
			list.i.mat[[j]][n[[j]] + 1, ] <- cumsum(list.i.mat[[j]][n[[j]] + 1, ]) + 1
			
			

			
		}
		
		assign("mrca.nodes", mrca.nodes, envir = local.env)	
		assign("nod.types", nod.types, envir = local.env)
		assign("n", n, envir=local.env)
		assign("list.s.nod", list.s.nod, envir = local.env)
		assign("list.i.mat", list.i.mat, envir = local.env)
	}
	read.data()
	create.mat()
	
		prepdata<-list()
		prepdata[["mrca.nodes"]]<-mrca.nodes
		prepdata[["nod.types"]]<-nod.types
		prepdata[["n"]]<-n
		prepdata[["list.s.nod"]]<-list.s.nod
		prepdata[["list.i.mat"]]<-list.i.mat
		prepdata[["internod"]]<-internod
		prepdata[["tree"]]<-tr

	
	return(prepdata)
}




.Random.seed <-
c(403L, 466L, 587738418L, 1617510649L, 827162932L, -19979044L, 
552747326L, -1043311631L, 1721577674L, -1380261381L, -1518707493L, 
-439575003L, -1928865654L, 1395407998L, 1898238562L, -1775798227L, 
-896243918L, 1092338237L, -1808341230L, 803954945L, 115819156L, 
-1617839223L, -1500835023L, 1731596144L, -1395032422L, -834029526L, 
-66260027L, -934680474L, -954955224L, 870755222L, 894735230L, 
1492152802L, -1516840172L, 1574578245L, 2099940816L, 1817880546L, 
2081979099L, 1390394861L, -1407843791L, 548845189L, 109260014L, 
1729531660L, -1199851141L, -1107970058L, 362187707L, -759295374L, 
834649977L, -1205536767L, 1054485235L, -1085550850L, 842844218L, 
-482475847L, 2043981789L, -1769227489L, 332825763L, -2099662045L, 
-987526581L, -279725111L, -71022307L, -667679381L, 1984554988L, 
1643909254L, -934143576L, 1008418256L, -1407894541L, 315557483L, 
185878668L, 1050298320L, -215356908L, 484019092L, -1001649176L, 
-334376090L, 866376527L, -611745782L, 503799641L, 1766207489L, 
-266505165L, -1288424609L, -1369764346L, 1184421900L, -529169951L, 
122514501L, 1886000357L, 1350544693L, 1145588081L, 16940921L, 
-303915333L, 1356280903L, -619360106L, -726486819L, 724559037L, 
-2059031429L, -522899790L, 1229706239L, 1897871880L, 1630127428L, 
-898180476L, 1311090645L, 1859271004L, -832856464L, -258118082L, 
710444571L, 1463038834L, 1224039787L, 1573728951L, -636478409L, 
-1556528830L, -284579283L, 2135486049L, 1406444288L, 2105466056L, 
-2131790298L, -1794896595L, -2139043119L, 409846950L, 1142185007L, 
684440703L, -185421710L, 1262099475L, 1786177441L, -1298032640L, 
-2058826270L, -1614602452L, 341531033L, -1392306582L, -12447312L, 
975491525L, -1799226639L, 782171043L, -239336424L, -297395476L, 
-403188711L, 1560467801L, 389583858L, -440005519L, 1937564139L, 
-83174601L, -846358577L, -1814894319L, 747130354L, 88811579L, 
-2095254205L, -2043949723L, 1980187827L, -1697132717L, 1921476114L, 
746987739L, -1229793049L, -1439869141L, -1044552624L, -975685883L, 
-76474900L, -132083950L, 1837905789L, -298364121L, 2045477833L, 
1379070320L, -43049550L, -647763545L, 623623161L, -2130053124L, 
1357218361L, -701449503L, -1164391541L, -45874879L, 1861775261L, 
1786657967L, 738454884L, 955265323L, 651645629L, -612747301L, 
1145501323L, -2013018609L, -1595836307L, 2103159765L, -1019047353L, 
1306125953L, -486248669L, -788948949L, 55541058L, 1993189299L, 
1951991977L, 1603747077L, -1286268365L, 624302103L, -2038014878L, 
1977381501L, -113778904L, -1490065431L, 1037589459L, 356462605L, 
-1216707424L, 2100958595L, 183971299L, 1329756504L, 43287615L, 
640749185L, -235218208L, 1471630354L, -869270756L, 557558896L, 
1455830146L, 1499063213L, -708627807L, -1468196519L, -94938226L, 
767042913L, 59860819L, -297750542L, -716631061L, -58456538L, 
1336416453L, 176297910L, -1107179866L, 2128362372L, -327407768L, 
-26912295L, 150520495L, -1881633578L, 1869705715L, 291396331L, 
-943208560L, -2058586499L, -79189532L, 750839594L, -1090146119L, 
-1051551164L, -749616063L, -842754803L, -1562652512L, -15277780L, 
15992047L, 677536079L, -1837518900L, -41602698L, 458524643L, 
-1323832709L, 1140755077L, 1630277074L, 239365417L, 1400540504L, 
583178452L, 1988170704L, -1487268773L, -32956974L, 1114408199L, 
119443147L, -1232691169L, 623042178L, 344776293L, 1344870270L, 
498229320L, 1839683873L, -521922816L, -1201503772L, -1986798283L, 
-507960543L, 612296719L, -676501160L, 1857960408L, -322464649L, 
-534337286L, -438500582L, 1399477182L, -1061370824L, 219916975L, 
1747903207L, 1830108764L, -121061373L, 860599359L, -814404002L, 
-853595289L, -1780570155L, -2080376185L, -1387164895L, -1333348910L, 
-2090453187L, -517920760L, -1918707498L, -1938045352L, -291630169L, 
-605990954L, 2117882929L, 1597108744L, 1529959278L, -1218283804L, 
-477455881L, 1307711443L, -378440075L, 1942614935L, -2093860923L, 
-46680420L, -2119354337L, 1038544548L, -1638475983L, -1771007862L, 
-1762440414L, -404197616L, -2011660083L, -1151186108L, 19048986L, 
-1064550733L, 2040826366L, 2052093609L, 400828080L, -312888235L, 
608975700L, -1275652451L, 291112672L, -439444885L, 1263001676L, 
2050125079L, -368621627L, 985882015L, 1924080961L, 1101451316L, 
1346109440L, 729830296L, -931641098L, -1948463251L, 1311630931L, 
1846385281L, -1743191843L, -1263704859L, -1238377588L, -281373411L, 
-1432936503L, 110613438L, -977596547L, 799451136L, 1702680853L, 
1618699071L, 1581757260L, 716769817L, -1587458855L, -358358718L, 
1996509129L, -329428797L, -1506981983L, 872289745L, 1281474247L, 
1285039483L, -2140654046L, 825466545L, -2132919571L, -1089781897L, 
1325861140L, -763018490L, -2024692040L, -577820905L, 1226710997L, 
-912239761L, 387123760L, -2005040853L, 951494500L, -1074952607L, 
-1616129783L, 677124990L, -340630143L, -1475722794L, 1400814712L, 
-1637599388L, -552381051L, -1209681335L, -1329621045L, 43988874L, 
1536200664L, -1335851273L, -1290087342L, -903252266L, 1700433090L, 
-1224398503L, 1586438145L, -2089453167L, 1326645970L, -1771245283L, 
1474501789L, -730429645L, -241835281L, -1047883976L, -947400366L, 
1547533675L, 1941750932L, 1880133324L, 166144633L, -697913984L, 
714040304L, 1217451172L, -1863390342L, 478706037L, -1467921491L, 
-1804915105L, 840207737L, 180633944L, 17949635L, -2134912283L, 
861854016L, 1911729570L, 689440543L, 540553976L, -2074219689L, 
-620029207L, 276592651L, -1807019958L, -2078674875L, 1049250959L, 
-1361301572L, -866662427L, -1467794599L, -1026076671L, -455717725L, 
-988357382L, 86643596L, 1430084088L, -1206487362L, 453809436L, 
84594537L, 877056073L, 1646557313L, -637099608L, -571473201L, 
88336847L, 2018168894L, -600717706L, 1337544124L, -1877897528L, 
-1877034842L, 357624824L, -1745140812L, 513877868L, -612112523L, 
-1698755336L, -1717081562L, -228133222L, 1175869227L, 864764467L, 
677622381L, -260681539L, 151475318L, 531814415L, 1614453231L, 
235154837L, -1960993780L, 188523290L, 917976680L, -1562870531L, 
1344960828L, -1006736655L, 1639059590L, 1339514508L, 1684226299L, 
1204527621L, 538382289L, 1399592320L, -1086433308L, -1330765841L, 
2065279148L, 260099932L, -481454512L, 1575715245L, 1215476623L, 
1748342662L, -1481091596L, -2061234323L, -245163848L, -1384489181L, 
1028769854L, 271490058L, 1768894520L, 1095628485L, 613947055L, 
-1601354678L, 1248113105L, 327668453L, -1196552756L, 51125508L, 
-69101495L, -877037054L, 547055794L, -657500523L, -1469909176L, 
1706827956L, -70393102L, 1566743039L, 1765373312L, 506766500L, 
1711165647L, -719432773L, 689342682L, -80924003L, 1844492687L, 
-1984216132L, 1506263805L, 1462741866L, -913282101L, 688670360L, 
-1214358932L, 1215583617L, 119171264L, -970743092L, -788029041L, 
875499338L, 826706298L, 1584055844L, -2056751086L, 2063434493L, 
1164049814L, -1777962865L, -39220482L, 696837036L, 102636668L, 
1956730588L, 1405588158L, -463383567L, -334513166L, -418412537L, 
785729168L, 118552228L, 26809754L, -220837898L, 692612087L, 275744387L, 
-243159246L, 236569044L, 139271402L, 600928097L, 631177185L, 
356687922L, -839436129L, 352307654L, -99659158L, -632267587L, 
-1005576706L, 2120879823L, 209037190L, 1765398707L, 1748388434L, 
-1786484695L, 1214591436L, -330131564L, 647065789L, 1667709299L, 
-1447378497L, 1065160253L, 614174021L, -628016014L, 937839850L, 
415898969L, 1493314756L, -349741096L, 763055983L, -1716904224L, 
-1815066645L, 1182802057L, -910328022L, 1300825297L, 469982446L, 
257671071L, 1475524710L, 1825413376L, -1237800751L, -2081276567L, 
354843691L, 1079996484L, 1243959318L, 128551078L, -2020258035L, 
-967985429L, -490404571L, -1992014791L, -949668137L, -379801628L, 
-1264746844L, -363628519L, 638827899L, -810472446L, 10169689L, 
339429544L, -1190485655L, 1558086213L, 2032712130L, 1944995537L, 
1374644549L, 1187625010L, -860043853L, 314395168L, -498354513L, 
-1657477764L, -1308681032L, -1549073167L, -1773826796L, 1703318481L, 
-525460750L, -524238015L, 389085456L, -1884619530L, 10365421L, 
-1025421002L, 128292418L, 1269030178L, -1354875906L, 954818155L, 
137509274L, 1878419511L, -512582943L, 2090215728L, 145270203L, 
-1265371544L, 955057410L, 1768935756L, -551242636L, -1702521926L, 
-2050656978L, -1594949615L, 1999242125L, 1116925955L, 2108995397L, 
-701222376L, 1499137954L, -876345993L, -878092955L, -1269795209L, 
-442501183L, -408007558L, 561231220L, 2023494022L)





